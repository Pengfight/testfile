from math import sqrt
import json
def uCF_dic_create():
    city_dic={}
    f=open('paths_without_traffic.json',encoding='utf-8')
    loaded=json.load(f)
    flag=0
    for route in loaded:
        for place in route:
            if flag==0:
                plan_id=place.get(u'plan_id')
                flag=1
            city=place.get(u'name')
            days=int(place.get(u'days'))
            city_dic.setdefault(plan_id,{})[city]=days
        #print(city_dic)
        #print(plan_id)
        flag=0
    return city_dic
def iCF_dic_create(city_dic):
    id_dic={}
    for cid in city_dic:
        for city in city_dic[cid]:
            id_dic.setdefault(city,{})[cid]=city_dic[cid][city]
        print(id_dic)
    return id_dic
def sim_distance(prefs,person1,person2):
    si={}
    for item in prefs[person1]:
        if item in prefs[person2]:
            si[item]=1
    if len(si)==0:
        return 0
    for item in prefs[person1]:
        if item in prefs[persons]:
            sum_of_squares=sum([)
