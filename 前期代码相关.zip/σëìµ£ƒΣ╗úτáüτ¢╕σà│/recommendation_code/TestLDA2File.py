import json
from CityRecomLDA import CityRecommendationLDA

def city_cnt():
    f=open('../data/paths_without_traffic.json','r',encoding='utf8')
    loaded=json.load(f)
    city_list=[]
    for route in loaded:
        for place in route:
            city=place.get(u'name')
            if city not in city_list:
                city_list.append(city)
    return city_list

if __name__=="__main__":
    recomm=CityRecommendationLDA()
    #get recommended citys
    city_list=city_cnt()
    #save recommendation-citys as city_remmendation.txt
    f=open('../result/city_remmendation_lda15_class.txt','w',encoding='utf8')
    for i in range(50):
        try:
            city_recom=recomm.get_recommended_citys(city_list[i],15 )
            #print(city_list[i])
            #city_recom=recommended.top_matches(item_dic,city_list[i])
            #print(city_remmd)
            f.write(city_list[i]+'\n')
            f.write(str(city_recom)+'\n')
        except:
            print('error')
    f.close()
