from math import sqrt
import json
def uCF_dic_create():
    city_dic={}
    f=open('../data/paths_without_traffic.json',encoding='utf-8')
    loaded=json.load(f)
    flag=0
    for route in loaded:
        for place in route:
            if flag==0:
                plan_id=place.get(u'plan_id')
                flag=1
            city=place.get(u'name')
            days=int(place.get(u'days'))
            city_dic.setdefault(plan_id,{})[city]=days
        #print(city_dic)
        #print(plan_id)
        flag=0
    return city_dic
def iCF_dic_create(city_dic):
    id_dic={}
    for cid in city_dic:
        for city in city_dic[cid]:
            #id_dic[city]=cid
            id_dic.setdefault(city,[]).append(cid)
        #print(id_dic)
    return id_dic
def calcorrection(k):
    id_dic=iCF_dic_create(uCF_dic_create())
    temp_citys=[]
    names=[]
    cor=0
    err=0
    sum_citys=0
    fin=open('../src/train4.info'+str(k)+'.full.txt','r',encoding='utf-8')
    for line in fin.readlines():
        names=[]
        '''citys.strip()
        citys_str=citys.split()
        for i in range(len(citys_str)):
            citys_str[i]=citys_str[i].split('()')
        del citys_str[0:2]
        for i in citys_str:
            prop,name=i.split(',')
            names.append(name)
        print(names)'''
        line=line.strip()
        line_str=line.split()
        for i in range(len(line_str)):
            line_str[i]=line_str[i].strip('()')
        del line_str[0:2]
        #print(line_str)
        for i in line_str:
            prob,name=i.split(',')
            names.append(name)
        #print(names)
        sum_citys+=len(names)
        for i in range(len(names)):
            for j in range(len(names)):
                if i==j:
                    break
                for cid in id_dic[names[i]]:
                    if cid in id_dic[names[j]]:
                        cor+=1
            if cor==0:
                err+=1
                #print(cor)
            cor=0
    print("%d-sum: %d"%(k,sum_citys))
    print("%d-error: %d"%(k,err))
    print("%d-rate: %f"%(k,err/sum_citys))
for i in range(10,17):
    calcorrection(i)
