import json
import os

def load_city_data():
    #citylist=[]
    citylist=' '
    days=0
    sum_city=0
    with open('path_json.json',encoding='utf-8') as fd:
        loaded = json.load(fd)
    for path in loaded:
        for place in path:
            if place.get(u'type') == 'place':
                sum_city+=1
                days=int(place.get(u'days'))
                place_name = place.get(u'name')
                #citylist.append(str(place_name))
                citylist+=(str(place_name)+' ')*days
                #print(place_name)
    fd.close()
    print(sum_city)
    return citylist
def write_citylist(city_list):
    f=open('city_doc3.txt','w',encoding='utf-8')
    f.write(str(city_list))
    f.close()
city=load_city_data()
#write_citylist(city)
