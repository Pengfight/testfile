from generate_topic_model import lda_learning
if __name__=="__main__":
    learn=lda_learning()
    learn.classfy_city_data()
    learn.data_format()
    learn.training(4,10,1000)
