import json
from CityRecomCF import RecommendationCF

def city_cnt():
    f=open('../data/paths_without_traffic.json','r',encoding='utf8')
    loaded=json.load(f)
    city_list=[]
    for route in loaded:
        for place in route:
            city=place.get(u'name')
            if city not in city_list:
                city_list.append(city)
    return city_list

if __name__=="__main__":
    recommended=RecommendationCF()
    #get icf dictionary
    item_dic=recommended.icf_dic_create(recommended.ucf_dic_create())
    #get recommended citys
    city_list=city_cnt()
    print(item_dic)
    #save recommendation-citys as city_remmendation.txt
    '''f=open('../data/city_remmendation.txt','w',encoding='utf8')
    for i in range(30):
        #print(city_list[i])
        city_recom=recommended.top_matches(item_dic,city_list[i])
        #print(city_remmd)
        f.write(city_list[i]+'\n')
        f.write(str(city_recom)+'\n')
    f.close()'''
