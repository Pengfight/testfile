import json
import os

def load_city_data():
    #citylist=[]
    timeDic={}
    city_timeDic={}
    time_sum=0.0
    with open('path_json_with_time1.json',encoding='utf-8') as fd:
        loaded = json.load(fd)
    for path in loaded:
        for place in path:
            time_sum=0.0
            if place.get(u'type') == 'place':
                place_name = place.get(u'name')
                trave_time=place.get(u'travel_times')
                for i in range(len(trave_time)):
                    time_sum+=float(trave_time[i])
                #print(time_sum)
                if time_sum==0.0:
                    time_sum=1
                city_timeDic.setdefault(place_name,[]).append(time_sum)
                #citylist.append(str(place_name))
                #citylist+=(str(place_name)+' ')*days
                #print(place_name)
    for citys in city_timeDic:
        #print(citys)
        timeDic[citys]=sum(city_timeDic[citys])
    fd.close()
    print(timeDic)
    return timeDic
def write_citylist(city_list):
    #print(city_list)
    f=open('cityHours_doc.txt','w',encoding='utf-8')
    for city in city_list:
        temp=(str(city)+' ')*int(city_list[city]/4)
        #print(temp)
        f.write(temp)
    f.close()
city=load_city_data()
#write_citylist(city)
