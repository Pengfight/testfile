import json
def city_cnt():
    f=open('paths_without_traffic.json','r',encoding='utf8')
    loaded=json.load(f)
    city_list=[]
    for route in loaded:
        for place in route:
            city=place.get(u'name')
            if city not in city_list:
                city_list.append(city)
    return city_list
def test_citytime():
    f=open('paths_without_traffic.json','r',encoding='utf8')
    loaded=json.load(f)
    city_list=[]
    times=0
    for route in loaded:
        for place in route:
            city=place.get(u'name')
            if city=='宇治':
                times+=int(place.get(u'days'))
            if city not in city_list:
                city_list.append(city)
    print(times)
    return city_list
test_citytime()
print(city_cnt())
print(len(city_cnt()))


                
