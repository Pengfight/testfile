import json

def loadjson():
    city=[]
    doc={}
    f = open("path_json_2017-11-13.json", encoding='utf-8')
    doc = json.load(f)
    for t in doc:
        if t['type']=='place':
            city.append(t['days'])
    print(city)
def loadjson2():
    s=''
    city=''
    f=open('path_json_2017-11-13.json','r',encoding='utf-8')
    for i in f.readlines():
        s+=i
    dic=eval(s)
    dic=eval(dic)
    for t in dic:
        city.join(t['name'])
    print(city)
    f.close()
loadjson2()
        
