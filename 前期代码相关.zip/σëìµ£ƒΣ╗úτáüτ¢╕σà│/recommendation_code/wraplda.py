import os
#os.popen("cd warplda/release/src/")
def data_format():
    '''
       format training data sets
    '''
    #copy data file
    os.system("cp ../data/cityHours_doc_train_dis_4.txt ../tools/warplda/data")
    os.system("cp ../data/cityHours_doc_train_dis_4-5.txt ../tools/warplda/data")
    os.system("cp ../data/cityHours_doc_train_dis_6-7.txt ../tools/warplda/data")
    os.system("cp ../data/cityHours_doc_train_dis_8-10.txt ../tools/warplda/data")
    os.system("cp ../data/cityHours_doc_train_dis_10.txt ../tools/warplda/data")
    #format data sets
    os.system("../tools/warplda/release/src/format -input ./warplda/data/cityHours_doc_train_dis_4.txt -prefix train4")
    os.system("../tools/warplda/release/src/format -input ./warplda/data/cityHours_doc_train_dis_4-5.txt -prefix train4_5")
    os.system("../tools/warplda/release/src/format -input ./warplda/data/cityHours_doc_train_dis_6-7.txt -prefix train6_7")
    os.system("../tools/warplda/release/src/format -input ./warplda/data/cityHours_doc_train_dis_8-10.txt -prefix train8_10")
    os.system("../tools/warplda/release/src/format -input ./warplda/data/cityHours_doc_train_dis_10.txt -prefix train10")
def training(days,k,niter):
    '''
       train data sets and get topic model
       :param days: the kind of data set
       (e.g. 4:4 days, 4_5:4-5 days, 6_7:6-7 days, 8_10:8-10 days, 10:10 days)
       :param k: the number of topics
       :param niter: the number of iterations
    '''
    os.system("./warplda/release/src/warplda --prefix train"+days+" --k "+k+" --niter "+niter)
