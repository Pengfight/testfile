from Recommendation import CityRecommendation
if __name__=="__main__":
    recom=CityRecommendation()
    given_cities=[['大阪',21.8],['东京',26.5]]
    recom_list=recom.get_recommended_citys(given_cities,'10',300)
    print(recom_list)
