from math import sqrt
import json
class CityRecommendationLDA(object):
    def __init__(self):
        pass

    #get time of every city
    def get_citytime(self):
        timeDic={}
        city_timeDic={}
        time_sum=0.0
        with open('../data/path_json_with_time_recom.json',encoding='utf-8') as fd:
            loaded = json.load(fd)
        for path in loaded:
            for place in path:
                time_sum=0.0
                if place.get(u'type') == 'place':
                    place_name = place.get(u'name')
                    trave_time=place.get(u'travel_times')
                    for i in range(len(trave_time)):
                        time_sum+=float(trave_time[i])
                    #print(time_sum)
                    if time_sum==0.0:
                        time_sum=1
                    city_timeDic.setdefault(place_name,[]).append(time_sum)
                    #citylist.append(str(place_name))
                    #citylist+=(str(place_name)+' ')*days
                    #print(place_name)
        for citys in city_timeDic:
            #print(citys)
            timeDic[citys]=sum(city_timeDic[citys])
        fd.close()
        #print(timeDic)
        return timeDic
    
    #format topic-model text
    def count_citys(self):
        city_dic={}
        number=0
        f= open('../topic-model/classfy_tpoic.txt','r',encoding='utf-8')
        #f= open('../topic-model/train.info_k'+'50.full.txt','r',encoding='utf-8')
        for line in f.readlines():
            line=line.strip()
            line_str=line.split()
            for i in range(len(line_str)):
                line_str[i]=line_str[i].strip('()')
            del line_str[0:2]
            for i in line_str:
                prob,name=i.split(',')
                city_dic.setdefault(str(number),{})[name]=float(prob)
            number+=1
        #print(city_dic)
        return city_dic
    
    def icf_dic_create(self,city_dic):
        id_dic={}
        for cid in city_dic:
            for city in city_dic[cid]:
                id_dic.setdefault(city,{})[cid]=city_dic[cid][city]
            #print(id_dic)
        return id_dic
    
    #recommendation
    def get_recommended_citys(self,city,n=10):
        city_dic=self.count_citys()
        id_dic=self.icf_dic_create(city_dic)
        temp_list=[]
        recom_list=[]
        timeDic=self.get_citytime()
        sum_time=0.0
        temp_max=0
        cnt=int(n*0.6)
        #get a sorted id_list 
        for cid in id_dic[city]:
            temp_list.append((id_dic[city][cid],cid))
        temp_list.sort()
        temp_list.reverse()
        #print(temp_list)
        #produce a recommended list
        for cid in temp_list:
            if len(recom_list) >cnt:
                break
            if cid[0]<0.8:
                for temp_city in city_dic[cid[1]]:
                    if (temp_city != city) and (len(recom_list)<cnt):
                        recom_list.append([city_dic[cid[1]][temp_city],temp_city])
        recom_list.append([temp_list[0][0],city])
        recom_list.sort()
        recom_list.reverse()
        #add modified coefficient
        if recom_list[0][0]>0.5:
            recom_list[0][0]=recom_list[0][0]/3.0
            
        for temp in recom_list:
            sum_time+=temp[0]
        for temp in recom_list:
            temp[0]=round((temp[0]/sum_time*n),1)
        #print(recom_list)
        return recom_list
        '''#use proportion of time as weight of days
        for temp_city in recom_list:
            temp_city[1]=timeDic[str(temp_city[0])]
            sum_time+=float(temp_city[1])
        for temp_city in recom_list:
            temp_city[1]=round((temp_city[1]/sum_time*n),3)
        print(recom_list)'''
    
    #calculate sim_distance
    def sim_distance(prefs,person1,person2):
        si={}
        if person1 not in prefs:
            return 0
        for item in prefs[person1]:
            if item in prefs[person2]:
                si[item]=1
        if len(si)==0:
            return 0
        sum_of_squares=sum([pow(prefs[person1][item]-prefs[person2][item],2) for item in prefs[person1] if item in prefs[person2]])
        return (1/(1+sqrt(sum_of_squares)))
    
    # calculate sim_pearson
    def sim_pearson(prefs,p1,p2):
        si={}
        sum1=0
        sum2=0
        if p1 not in prefs:
            return 0
        for item in prefs[p1]:
            if item in prefs[p2]:
                si[item]=1
        n=len(si)
        if n==0:
            return 0
        for it in si:
            sum1+=prefs[p1][it]
            sum2+=prefs[p2][it]
        sum1Sq=sum([pow(prefs[p1][it],2)for it in si])
        sum2Sq=sum([pow(prefs[p2][it],2)for it in si])
        pSum=sum([prefs[p1][it]*prefs[p2][it] for it in si])
        num=pSum-(sum1*sum2/n)
        den=sqrt((sum1Sq-pow(sum1,2)/n)*(sum2Sq-pow(sum2,2)/n))
        if den==0:
            return 0
        r=round((num/den),4)
        return r


    


