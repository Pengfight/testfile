from math import sqrt
import json
class CityRecommendationLDA(object):
    def __init__(self):
        pass

    #get time of every city
    def get_citytime(self):
        timeDic={}
        city_timeDic={}
        time_sum=0.0
        with open('../data/path_json_with_time_recom.json',encoding='utf-8') as fd:
            loaded = json.load(fd)
        for path in loaded:
            for place in path:
                time_sum=0.0
                if place.get(u'type') == 'place':
                    place_name = place.get(u'name')
                    trave_time=place.get(u'travel_times')
                    for i in range(len(trave_time)):
                        time_sum+=float(trave_time[i])
                    #print(time_sum)
                    if time_sum==0.0:
                        time_sum=1
                    city_timeDic.setdefault(place_name,[]).append(time_sum)
                    #citylist.append(str(place_name))
                    #citylist+=(str(place_name)+' ')*days
                    #print(place_name)
        for citys in city_timeDic:
            #print(citys)
            timeDic[citys]=sum(city_timeDic[citys])
        fd.close()
        #print(timeDic)
        return timeDic
    #format topic-model text
    def count_citys(self):
        city_dic={}
        number=0
        f= open('../topic-model/train.info_n'+'50.full.txt','r',encoding='utf-8')
        for line in f.readlines():
            line=line.strip()
            line_str=line.split()
            for i in range(len(line_str)):
                line_str[i]=line_str[i].strip('()')
            del line_str[0:2]
            for i in line_str:
                prob,name=i.split(',')
                city_dic.setdefault(str(number),{})[name]=float(prob)
            number+=1
        #print(city_dic)
        return city_dic
    def icf_dic_create(self,city_dic):
        id_dic={}
        for cid in city_dic:
            for city in city_dic[cid]:
                id_dic.setdefault(city,{})[cid]=city_dic[cid][city]
            #print(id_dic)
        return id_dic
    #calculate sim_distance
    def sim_distance(prefs,person1,person2):
        si={}
        if person1 not in prefs:
            return 0
        for item in prefs[person1]:
            if item in prefs[person2]:
                si[item]=1
        if len(si)==0:
            return 0
        sum_of_squares=sum([pow(prefs[person1][item]-prefs[person2][item],2) for item in prefs[person1] if item in prefs[person2]])
        return (1/(1+sqrt(sum_of_squares)))
    # calculate sim_pearson
    def sim_pearson(prefs,p1,p2):
        si={}
        sum1=0
        sum2=0
        if p1 not in prefs:
            return 0
        for item in prefs[p1]:
            if item in prefs[p2]:
                si[item]=1
        n=len(si)
        if n==0:
            return 0
        for it in si:
            sum1+=prefs[p1][it]
            sum2+=prefs[p2][it]
        sum1Sq=sum([pow(prefs[p1][it],2)for it in si])
        sum2Sq=sum([pow(prefs[p2][it],2)for it in si])
        pSum=sum([prefs[p1][it]*prefs[p2][it] for it in si])
        num=pSum-(sum1*sum2/n)
        den=sqrt((sum1Sq-pow(sum1,2)/n)*(sum2Sq-pow(sum2,2)/n))
        if den==0:
            return 0
        r=round((num/den),4)
        return r

    #match citys
    def top_matches(self,prefs,person,n=10,similarity=sim_distance):
        scores=[]
        sum_time=0.0
        timeDic={}
        timeDic=self.get_citytime()
        scores=[[similarity(prefs,person,other),other]for other in prefs if other != person]
        scores.sort()
        scores.reverse()
        cnt=int(n*0.5)
        '''#use proportion of time as weight of days
        for city in scores[0:cnt]:
            city[0]=timeDic[str(city[1])]
            sum_time+=float(city[0])
        for city in scores[0:cnt]:
            city[0]=int(city[0]/sum_time*n)'''
        return scores[0:cnt]


