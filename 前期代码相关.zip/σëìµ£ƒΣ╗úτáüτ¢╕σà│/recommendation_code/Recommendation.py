from math import sqrt
import json
class CityRecommendation(object):
    def __init__(self):
        pass

    def get_citytime(self):
        '''
           get time of every city
           :return trip-time dictionary
        '''
        timeDic={}
        city_timeDic={}
        time_sum=0.0
        with open('../data/path_json_with_time_recom.json',encoding='utf-8') as fd:
            loaded = json.load(fd)
        for path in loaded:
            for place in path:
                time_sum=0.0
                if place.get(u'type') == 'place':
                    place_name = place.get(u'name')
                    trave_time=place.get(u'travel_times')
                    for i in range(len(trave_time)):
                        time_sum+=float(trave_time[i])
                    #print(time_sum)
                    if time_sum==0.0:
                        time_sum=1
                    city_timeDic.setdefault(place_name,[]).append(time_sum)
                    #citylist.append(str(place_name))
                    #citylist+=(str(place_name)+' ')*days
                    #print(place_name)
        for citys in city_timeDic:
            #print(citys)
            timeDic[citys]=sum(city_timeDic[citys])
        fd.close()
        #print(timeDic)
        return timeDic
    
    def topic_cities_dic(self,classfy):
        '''
           format topic-model text
           :param classfy:the kind of topic-model data set
           :return city dictionary
        '''
        city_dic={}
        number=0
        f= open('../data/train'+str(classfy)+'.info.full.txt','r',encoding='utf-8')
        for line in f.readlines():
            line=line.strip()
            line_str=line.split()
            for i in range(len(line_str)):
                line_str[i]=line_str[i].strip('()')
            del line_str[0:2]
            for i in line_str:
                prob,name=i.split(',')
                city_dic.setdefault(str(number),{})[name]=float(prob)
            number+=1
        #print(city_dic)
        return city_dic
    
    def icf_dic_create(self,city_dic):
        id_dic={}
        for cid in city_dic:
            for city in city_dic[cid]:
                id_dic.setdefault(city,{})[cid]=city_dic[cid][city]
            #print(id_dic)
        return id_dic
    
    def get_recommended_citys(self,given_cities,given_topic,constrains):
        '''
           produce recommendation list
           :param given_cities:the city that users like
           e.g. given_cites = [(city_id1, city_time1), (city_id2, city_time2), ....]
           :param given_topic:a topic model text of LDA that you will use
           e.g. given_topic=4 or 4_5 or 6_7 or 8_10 or 10
           :param constrains:the total time of trip
           e.g. constrains=125
           :return city list have the following format:
           [(city_id1, city_time1), (city_id2, city_time2), ....]
        '''
        topic_dic=self.topic_cities_dic(given_topic)
        id_dic=self.icf_dic_create(topic_dic)
        temp_list=[]
        recom_list=[]
        timeDic=self.get_citytime()
        sum_time=0.0
        temp_max=0
        pro_time=0
        temp_given_cities=[]
        #get total time of given cities
        for city_time in given_cities:
            pro_time+=city_time[1]
            temp_given_cities.append(city_time[0])
        #get the rest time 
        rest_time=constrains-pro_time
        #get the amount of recommended cities
        cnt=int(rest_time/24*0.5)
        #get a sorted id_list
        for given_city in given_cities:
            for cid in id_dic[given_city[0]]:
                temp_list.append((id_dic[given_city[0]][cid],cid))
        temp_list.sort()
        temp_list.reverse()
        #print(temp_list)
        #produce a recommended list
        for given_city in given_cities:
            for cid in temp_list:
                if len(recom_list) >cnt:
                    break
                if cid[0]<0.8:
                    for temp_city in topic_dic[cid[1]]:
                        if (temp_city not in temp_given_cities) and (len(recom_list)<cnt):
                            recom_list.append([temp_city,topic_dic[cid[1]][temp_city]])
        #recom_list.append([temp_list[0][0],city])
        #print(recom_list)
        #add modified coefficient
        if recom_list[0][1]>0.8:
            recom_list[0][1]=recom_list[0][1]/5.0
        elif recom_list[0][1]>0.5:
            recom_list[0][1]=recom_list[0][1]/2.5
            
        for temp in recom_list:
            sum_time+=temp[1]
        for temp in recom_list:
            temp[1]=round((temp[1]/sum_time*rest_time),1)
        for given_city in given_cities:
            recom_list.append(given_city)
        recom_list.sort()
        recom_list.reverse()
        return recom_list
        '''#use proportion of time as weight of days
        for temp_city in recom_list:
            temp_city[1]=timeDic[str(temp_city[0])]
            sum_time+=float(temp_city[1])
        for temp_city in recom_list:
            temp_city[1]=round((temp_city[1]/sum_time*n),3)
        print(recom_list)'''
    
