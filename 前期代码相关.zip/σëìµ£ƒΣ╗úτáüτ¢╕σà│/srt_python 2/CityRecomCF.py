from math import sqrt
import json

class RecommendationCF(object):
    def __init__(self):
        pass

    # create ucf dictionary
    def ucf_dic_create(self):
        city_dic={}
        f=open('../data/paths_without_traffic.json',encoding='utf-8')
        loaded=json.load(f)
        flag=0
        for route in loaded:
            for place in route:
                if flag==0:
                    plan_id=place.get(u'plan_id')
                    flag=1
                city=place.get(u'name')
                days=int(place.get(u'days'))
                city_dic.setdefault(plan_id,{})[city]=days
            flag=0
        return city_dic

    # create icf dictionary
    def icf_dic_create(self,city_dic):
        id_dic={}
        for cid in city_dic:
            for city in city_dic[cid]:
                id_dic.setdefault(city,{})[cid]=city_dic[cid][city]
            #print(id_dic)
        return id_dic
    
    # calculate sim_distance
    def sim_distance(prefs,person1,person2):
        si={}
        for item in prefs[person1]:
            if item in prefs[person2]:
                si[item]=1
        if len(si)==0:
            return 0
        for item in prefs[person1]:
            if item in prefs[person2]:
                sum_of_squares=sum(pow(prefs[person1][item]-prefs[person2][item],2))
        return (1/(1+sqrt(sum_of_squares)))
    
    # calculate sim_pearson
    def sim_pearson(prefs,p1,p2):
        si={}
        sum1=0
        sum2=0
        for item in prefs[p1]:
            if item in prefs[p2]:
                si[item]=1
        n=len(si)
        if n==0:
            return 0
        for it in si:
            sum1+=prefs[p1][it]
            sum2+=prefs[p2][it]
        sum1Sq=sum([pow(prefs[p1][it],2)for it in si])
        sum2Sq=sum([pow(prefs[p2][it],2)for it in si])
        pSum=sum([prefs[p1][it]*prefs[p2][it] for it in si])
        num=pSum-(sum1*sum2/n)
        den=sqrt((sum1Sq-pow(sum1,2)/n)*(sum2Sq-pow(sum2,2)/n))
        if den==0:
            return 0
        r=round((num/den),4)
        return r
    
    # match citys
    def top_matches(self,prefs,person,n=5,similarity=sim_pearson):
        scores=[]
        '''for other in prefs:
            if other!=person:
                scores.append(similarity(prefs,person,other))'''
        scores=[(similarity(prefs,person,other),other)for other in prefs if other != person]
        scores.sort()
        scores.reverse()
        return scores[0:n]
    
    def get_recommendtions(self,prefs,person,similarity=sim_pearson):
        totals={}
        simSums={}
        for other in prefs:
            if other==person:
                continue
            sim=similarity(prefs,person,other)
            if sim<0:
                continue
            for item in prefs[other]:
                if item not in prefs[person] or prefs[person][item]==0:
                  total[item]+=prefs[other][item]*sim
                  simSums.setdefault(item,0)
                  simSums[item]+=sim
        rankings=[(total/simSums[item],item)for item,total in totals.items()]
        rankings.sort()
        rankings.reverse()
        return rankings
    
    def get_recommended_items(self,prefs,itemSim,user):
        userRatings=prefs[user]
        scores={}
        totalSim={}
        for (item,rating) in userRatings.items():
            for (similarity,item2) in itemSim[item]:
                if item2 in userRatings:
                    continue
                scores.setdefault(item2,0)
                scores[item2]+=similarity*rating
                totalSim.setdefault(item2,0)
                totalSim[item2]+=similarity
        rankings=[(score/totalSim[item],item) for item,score in scores.items()]
        rankings.sort()
        rankings.reverse()
        return rankings       
     
