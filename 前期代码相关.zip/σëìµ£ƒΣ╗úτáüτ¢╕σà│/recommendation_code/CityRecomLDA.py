from math import sqrt
import json
class CityRecommendationLDA(object):
    def __init__(self):
        pass

    def get_citytime(self):
        '''
           get time of every city
           :return trip-time dictionary
        '''
        timeDic={}
        city_timeDic={}
        time_sum=0.0
        with open('../data/path_json_with_time_recom.json',encoding='utf-8') as fd:
            loaded = json.load(fd)
        for path in loaded:
            for place in path:
                time_sum=0.0
                if place.get(u'type') == 'place':
                    place_name = place.get(u'name')
                    trave_time=place.get(u'travel_times')
                    for i in range(len(trave_time)):
                        time_sum+=float(trave_time[i])
                    #print(time_sum)
                    if time_sum==0.0:
                        time_sum=1
                    city_timeDic.setdefault(place_name,[]).append(time_sum)
                    #citylist.append(str(place_name))
                    #citylist+=(str(place_name)+' ')*days
                    #print(place_name)
        for citys in city_timeDic:
            #print(citys)
            timeDic[citys]=sum(city_timeDic[citys])
        fd.close()
        #print(timeDic)
        return timeDic
    
    def count_citys(self,days):
        '''
           format topic-model text
           :param days:the kind of topic-model data set
           :return city dictionary
        '''
        city_dic={}
        number=0
        c=''
        if days>20:
            c='10'
        elif days>=16:
            c='8_10'
        elif days>=12:
            c='6_7'
        elif days>=8:
            c='4_5'
        else:
            c='4'
        f= open('../topic-model/train'+c+'.info.full.txt','r',encoding='utf-8')
        for line in f.readlines():
            line=line.strip()
            line_str=line.split()
            for i in range(len(line_str)):
                line_str[i]=line_str[i].strip('()')
            del line_str[0:2]
            for i in line_str:
                prob,name=i.split(',')
                city_dic.setdefault(str(number),{})[name]=float(prob)
            number+=1
        #print(city_dic)
        return city_dic
    
    def icf_dic_create(self,city_dic):
        id_dic={}
        for cid in city_dic:
            for city in city_dic[cid]:
                id_dic.setdefault(city,{})[cid]=city_dic[cid][city]
            #print(id_dic)
        return id_dic
    
    def get_recommended_citys(self,city,n=10):
        '''
           produce recommendation list
           :param city:the city that users like
           :param n:the days of trip
           :return city list have the following format:
           [[120.4, '大阪'], [121.6, '京都'], [27.4, '名古屋']]
        '''
        city_dic=self.count_citys(n)
        id_dic=self.icf_dic_create(city_dic)
        temp_list=[]
        recom_list=[]
        timeDic=self.get_citytime()
        sum_time=0.0
        temp_max=0
        cnt=int(n*0.5)
        #get a sorted id_list 
        for cid in id_dic[city]:
            temp_list.append((id_dic[city][cid],cid))
        temp_list.sort()
        temp_list.reverse()
        print(temp_list)
        #produce a recommended list
        for cid in temp_list:
            if len(recom_list) >cnt:
                break
            if cid[0]<0.8:
                for temp_city in city_dic[cid[1]]:
                    if (temp_city != city) and (len(recom_list)<cnt):
                        recom_list.append([city_dic[cid[1]][temp_city],temp_city])
        recom_list.append([temp_list[0][0],city])
        recom_list.sort()
        recom_list.reverse()
        print(recom_list)
        #add modified coefficient
        if recom_list[0][0]>0.8:
            recom_list[0][0]=recom_list[0][0]/5.0
        elif recom_list[0][0]>0.5:
            recom_list[0][0]=recom_list[0][0]/2.5
            
        for temp in recom_list:
            sum_time+=temp[0]
        for temp in recom_list:
            temp[0]=round((temp[0]/sum_time*n),1)
        print(recom_list)
        return recom_list
        '''#use proportion of time as weight of days
        for temp_city in recom_list:
            temp_city[1]=timeDic[str(temp_city[0])]
            sum_time+=float(temp_city[1])
        for temp_city in recom_list:
            temp_city[1]=round((temp_city[1]/sum_time*n),3)
        print(recom_list)'''
    
