import numpy as np
import json
import os

def load_path_data():
    with open('path_json.json',encoding='utf-8') as fd:
        loaded = json.load(fd)
    data = []
    for path in loaded:
        data_path = []
        for place in path:
            place_id = place.get(u'id')
            days = int(place.get(u'days'))
            for day in range(days):
                data_path.append(place_id)
        data.append(data_path)
    return data
print(load_path_data())
