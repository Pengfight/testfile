import json
import os

def load_city_data():
    #citylist=[]
    time_sum=0.0
    rid=0
    tid=0
    with open('path_json_with_time1.json',encoding='utf-8') as fd:
        loaded = json.load(fd)
    outfile=open('cityHours_doc_train_dis.txt','w',encoding='utf-8')
    for path in loaded:
        '''if rid>=60:
            break'''
        rid+=1
        tid+=1
        outfile.write(str(rid)+' '+str(tid)+' ')
        for place in path:
            time_sum=0.0
            if place.get(u'type') == 'place':
                place_name = place.get(u'name')
                trave_time=place.get(u'travel_times')
                for i in range(len(trave_time)):
                    time_sum+=float(trave_time[i])
                #print(time_sum)
                if int(time_sum) == 0:
                    time_sum=4
                citys=(str(place_name)+' ')*int((time_sum/4))
                outfile.write(citys)
                #city_timeDic.setdefault(place_name,[]).append(time_sum)
                #citylist.append(str(place_name))
                #citylist+=(str(place_name)+' ')*days
                #print(place_name)
        outfile.write('\n')
    fd.close()
    outfile.close()
    #print(timeDic)
    #return timeDic
load_city_data()
#write_citylist(city)
