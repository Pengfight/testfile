from math import sqrt
import json
def uCF_dic_create():
    city_dic={}
    f=open('paths_without_traffic.json',encoding='utf-8')
    loaded=json.load(f)
    flag=0
    for route in loaded:
        for place in route:
            if flag==0:
                plan_id=place.get(u'plan_id')
                flag=1
            city=place.get(u'name')
            days=int(place.get(u'days'))
            city_dic.setdefault(plan_id,{})[city]=days
        #print(city_dic)
        #print(plan_id)
        flag=0
    return city_dic
def iCF_dic_create(city_dic):
    id_dic={}
    for cid in city_dic:
        for city in city_dic[cid]:
            id_dic.setdefault(city,{})[cid]=city_dic[cid][city]
        print(id_dic)
    return id_dic
#利用欧几里得计算之间的相似度
def sim_distance(prefs,person1,person2):
    si={}
    for item in prefs[person1]:
        if item in prefs[person2]:
            si[item]=1
    if len(si)==0:
        return 0
    for item in prefs[person1]:
        if item in prefs[person2]]):
            sum_of_squares=sum([pow(prefs[person1][item]-prefs[person2][item],2) 
    return 1/(1+sqrt(sum_of_squares)
def sim_pearson(prefs,p1,p2):
    si={}
    for item in prefs[p1]:
        if item in prefs[p2]:
            si[item]=1
    n=len(si)
    if n==0:
        return 0
    sum1=sum([prefs[p1][it] for it in si])
    sum2=sum([prefs[p2][it] for it in si])

    sum1Sq=sum([pow(prefs[p1][it],2)for it in si])
    sum2Sq=sum([pow(prefs[p2][it],2)for it in si])
    pSum=sum([prefs[p1][it]*prefs[p2][it] for it in si])
    num=pSum-(sum1*sum2/n)
    den=sqrt((sum1Sq-pow(sum1,2)/n)*(sum2Sq-pow(sum2,2)/n))
    if den == 0:
        return 0
    r=num/den
    return r
#match
def top_Matches(prefs,person,n=5,similarity=sim_pearson):
    for other in perfs:
        if other!=person:
            scores=similarity(prefs,person,other)
    scores.sort()
    scores.reverse()
    return scores[0:n]
def get_Recommendtions(prefs,person,similarity=sim_pearson):
    totals={}
    simSums={}
    for other in prefs:
        if other==person:
            continue
        sim=similarity(prefs,person,other)
        if sim<0:
            continue
        for item in prefs[other]:
            if item not in prefs[person] or prefs[person][item]==0:
              total[item]+=prefs[other][item]*sim
              simSums.setdefault(item,0)
              simSums[item]+=sim
    rankings=[(total/simSums[item],item)for item,total in totals.items()]
    rankings.sort()
    rankings.reverse()
    return rankings
def calculateSimilarItems(itemsPrefs,n=10):
    result={}
    c=0
    for item in itemPrefs:
        c+=1
        if c%100==0:
            print("%d %d" %(c,len(itemPrefs))
        scores=topMatches(itemPrefs,item,n=n,similarity=sim_distance)
        result[item]=scores
    return result
def getRecommendedItems(prefs,itemSim,user):
    userRatings=prefs[user]
    scores={}
    totalSim={} 
    #循环遍历由当前用户评分的物品
    for (item,rating) in userRatings.items():
        for (similarity,item2) in itemSim[item]:
            if item2 in userRatings:
                continue
            scores.setdefault(item2,0)
            scores[item2]+=similarity*rating
            totalSim.setdefault(item2,0)
            totalSim[item2]+=similarity
    rankings=[(score/totalSim[item],item) for item,score in scores.items()] 
    rankings.sort()
    rankings.reverse()
    return rankings   

item_dic=iCF_dic_create(uCF_dic_create())          
     
