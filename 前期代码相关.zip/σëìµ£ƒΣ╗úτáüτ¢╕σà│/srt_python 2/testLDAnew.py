from CityRecomLDA_new import CityRecommendationLDA
if __name__=="__main__":
    city=input("please input a city that you want to go to(exp:大阪,default value:大阪)")
    days=input("please input days that you hope(exp:10,default value:10)")
    if city == ' ':
        city='大阪'
    if days == ' ':
        days=10
    recomm=CityRecommendationLDA()
    city_list=recomm.get_recommended_citys(city,int(days))
    print(city_list)
